import { HttpResponse } from "@angular/common/http";
import {
  Component,
  inject,
  OnInit,
  signal,
  ViewEncapsulation,
} from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { IPost } from "app/entities/nk-post/nk-post.model";
import { Observable } from "rxjs";
import { finalize } from "rxjs/operators";
import { PostService } from "../nk-post.service";

import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import SharedModule from "app/shared/shared.module";

import { MatChipInputEvent, MatChipsModule } from "@angular/material/chips";
import { MatDialog } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";
import { MatTooltipModule } from "@angular/material/tooltip";
import { IAttachment } from "app/entities/nk-attachment/nk-attachment.model";
import { AttachmentCategory } from "app/entities/nk-enumerations/nk-attachment-type.model";
import { Status } from "app/entities/nk-enumerations/status.model";
import { Subject } from "app/entities/nk-enumerations/subject.model";
import { Visibility } from "app/entities/nk-enumerations/visibility.model";
import { AlertService } from "app/shared/alert/alert.service";
import { fadeInUp400ms } from "app/shared/animations/fade-in-up.animation";
import { scaleInOut400ms } from "app/shared/animations/scale-in-out.animation";
import { scaleInOutAnimation150ms } from "app/shared/animations/stagger.animation";
import { AudioPlyrComponent } from "app/shared/audio-plyr/audio-plyr.component";
import { RemoveHtmlPipe } from "app/shared/pipes/remove-html.pipe";
import { VideoPlyrComponent } from "app/shared/video-plyr/video-plyr.component";
import { AttachmentFileInputComponent } from "./nk-attachment-dialog/nk-attachment-file-input/nk-attachment-file-input.component";
import { AttachmentImageComponent } from "./nk-attachment-dialog/nk-attachment-image/nk-attachment-image.component";
import { AttachmentTextDialogComponent } from "./nk-attachment-dialog/nk-attachment-text/nk-attachment-text.component";
import { AttachmentVideoComponent } from "./nk-attachment-dialog/nk-attachment-video/nk-attachment-video.component";
import { AttachmentVoiceRecoderComponent } from "./nk-attachment-dialog/nk-attachment-voice-recorder/nk-attachment-voice-recorder.component";

@Component({
  standalone: true,
  selector: "app-post-update",
  templateUrl: "./nk-post-update.component.html",
  imports: [
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    AudioPlyrComponent,
    VideoPlyrComponent,
    RemoveHtmlPipe,
    MatInputModule,
    MatChipsModule,
    MatIconModule,
    MatSelectModule,
    MatFormFieldModule,
    MatTooltipModule,
  ],
  animations: [fadeInUp400ms, scaleInOut400ms, scaleInOutAnimation150ms],

  encapsulation: ViewEncapsulation.None, // Disable encapsulation
})
export class PostUpdateComponent implements OnInit {
  readonly dialog = inject(MatDialog);
  private postService = inject(PostService);
  private alertService = inject(AlertService);
  private activatedRoute = inject(ActivatedRoute);

  protected post = signal<IPost>(null);
  protected isSaving = signal(false);
  protected isLoading = signal(false);
  protected updatedAttachments: IAttachment[] = [];
  protected deletedAttachments: IAttachment[] = [];
  protected subjectValues = Object.keys(Subject);
  protected visibilityValues = Object.keys(Visibility);
  protected statusValues = Object.keys(Status);
  protected keywords: string[] = [];

  expandedIndexes: Set<number> = new Set<number>();

  postForm = new FormGroup({
    id: new FormControl(null),
    title: new FormControl(null, [Validators.required]),
    subtitle: new FormControl(null),
    keywords: new FormControl(null),
    subject: new FormControl(null, [Validators.required]),
    at: new FormControl(null),
    lastUpdate: new FormControl(null),
    visibility: new FormControl(null),
    content: new FormControl(null, [
      Validators.required,
      Validators.maxLength(1000),
    ]),
    status: new FormControl(null),
    account: new FormControl(null),
  });

  ngOnInit(): void {
    this.isLoading.set(true);
    this.activatedRoute.data.subscribe(({ post }) => {
      this.post.set(post);
      this.postForm.patchValue(this.post());
      this.keywords = this.post()?.keywords.split(",") || [];
      this.updatedAttachments = this.post().attachments;
    });
  }

  save(): void {
    this.isSaving.set(true);
    const keywords = this.keywords.reduce(
      (prev: string, curr: string) => `${prev},${curr}`
    );
    const post: IPost = { ...this.postForm.value, keywords };
    const newAttachments = this.updatedAttachments.filter((el) => {
      if (el.id) {
        const find = this.post().attachments.find((item) => item.id == el.id);
        return find.position != el.position || find.dirty;
      }
      return true;
    });
    if (post.id !== null) {
      const deletedAttachments = this.deletedAttachments.map((el) => ({
        id: el.id,
        url: el.url,
        posterUrl: el.posterUrl,
      }));
      this.subscribeToSaveResponse(
        this.postService.update(post, newAttachments, deletedAttachments)
      );
    } else {
      this.subscribeToSaveResponse(
        this.postService.create(post, newAttachments)
      );
    }
  }

  private subscribeToSaveResponse(
    result: Observable<HttpResponse<IPost>>
  ): void {
    result.pipe(finalize(() => this.isSaving.set(false))).subscribe({
      next: () => {
        this.alertService.addAlert({
          type: "success",
          message: "Enregistrer avec succès!",
        });
        this.previousState();
      },
      error: () =>
        this.alertService.addAlert({
          type: "error",
          message: "Une erreur s'est produite lors de l'enregistrement.",
        }),
    });
  }

  protected addkeyword(event: MatChipInputEvent) {
    const keyword = (event.value || "").trim();
    if (keyword.length > 0) {
      this.keywords.push("#" + keyword);
    }
  }

  protected removekeyword(i: number) {
    this.keywords = this.keywords.filter((value, idx) => idx != i);
  }

  openAttachmentTextDialog(position?: number): void {
    const dialogRef = this.dialog.open(AttachmentTextDialogComponent, {
      disableClose: true,
      width: "90vw",
      maxWidth: "100vw",
      maxHeight: "90vw",
      enterAnimationDuration: "300ms",
      exitAnimationDuration: "150ms",
    });
    const idx = this.updatedAttachments.findIndex(
      (e) => e.position == position
    );
    if (idx > -1) {
      dialogRef.componentInstance.textContent =
        this.updatedAttachments[idx].textContent;
    }
    dialogRef
      .afterClosed()
      .subscribe((attachment: IAttachment) =>
        this.afterClosed(position, attachment)
      );
  }

  openAttachmentVoiceRecoder(position?: number): void {
    const dialogRef = this.dialog.open(AttachmentVoiceRecoderComponent, {
      disableClose: true,
      width: "500px",
      height: "350px",
      enterAnimationDuration: "300ms",
      exitAnimationDuration: "150ms",
    });

    dialogRef
      .afterClosed()
      .subscribe((attachment: IAttachment) =>
        this.afterClosed(position, attachment)
      );
  }

  openAttachmentVideo(position?: number): void {
    const dialogRef = this.dialog.open(AttachmentVideoComponent, {
      disableClose: true,
      width: "500px",
      enterAnimationDuration: "300ms",
      exitAnimationDuration: "150ms",
    });
    const idx = this.updatedAttachments.findIndex(
      (e) => e.position == position
    );
    if (idx > -1) {
      dialogRef.componentInstance.attachment.set(this.updatedAttachments[idx]);
    }
    dialogRef
      .afterClosed()
      .subscribe((attachment) => this.afterClosed(position, attachment));
  }

  openAttachmentImage(position?: number): void {
    const dialogRef = this.dialog.open(AttachmentImageComponent, {
      disableClose: true,
      width: "500px",
      enterAnimationDuration: "300ms",
      exitAnimationDuration: "150ms",
    });
    const idx = this.updatedAttachments.findIndex(
      (e) => e.position == position
    );
    if (idx > -1) {
      dialogRef.componentInstance.attachment.set(this.updatedAttachments[idx]);
    }
    dialogRef
      .afterClosed()
      .subscribe((attachment) => this.afterClosed(position, attachment));
  }

  openAttachmentFileInput(position?: number): void {
    const dialogRef = this.dialog.open(AttachmentFileInputComponent, {
      disableClose: true,
      width: "500px",
      enterAnimationDuration: "300ms",
      exitAnimationDuration: "150ms",
    });

    dialogRef
      .afterClosed()
      .subscribe((attachment: IAttachment) =>
        this.afterClosed(position, attachment)
      );
  }

  private afterClosed(position?: number, attachment?: IAttachment) {
    if (attachment) {
      if (position) {
        this.replace(position, attachment);
      } else {
        this.append(attachment);
      }
    }
  }

  remove(attachment: IAttachment) {
    if (attachment.id) {
      this.deletedAttachments.push(attachment);
    }
    this.updatedAttachments = this.updatedAttachments.filter(
      (e) => e.position != attachment.position
    );
  }

  /**
   * Add a new Attachment to the list.
   *
   * @param attachment
   * @param file video, image or ducument file.
   * @param poster is used for an attachment type video.
   */
  append(attachment: IAttachment) {
    const positions = this.updatedAttachments.map((e) => e.position);
    attachment.position = Math.max(...positions, 1) + 1;
    this.updatedAttachments.push(attachment);
  }

  /**
   * Replace an existing attachment with the given on.
   *
   * @param position
   * @param attachment
   * @param file
   * @param poster
   */
  replace(position: number, attachment: IAttachment) {
    const idx = this.updatedAttachments.findIndex(
      (e) => e.position == position
    );
    const existsAttachement = this.updatedAttachments[idx];
    if (existsAttachement.id) {
      this.deletedAttachments.push(existsAttachement);
    }
    attachment.position = position; // update attachment's position.
    this.updatedAttachments[idx] = attachment; // now replace the former attachment with the new one.
    this.updatedAttachments[idx].dirty = true;
  }

  protected moveup(attachment: IAttachment) {
    this.updatedAttachments = this.updatedAttachments.sort((e) => e.position);
    const idx = this.updatedAttachments.findIndex(
      (e) => e.position == attachment.position
    );
    const switch_with_idx: number =
      idx > 0 ? idx - 1 : this.updatedAttachments.length - 1;
    const tmp: IAttachment = this.updatedAttachments[idx];
    this.updatedAttachments[idx] = this.updatedAttachments[switch_with_idx];
    this.updatedAttachments[switch_with_idx] = tmp;
    this.updatedAttachments = this.updatedAttachments.map((element, i) => {
      element.position = i + 1;
      return element;
    });
  }

  protected movedown(attachment: IAttachment) {
    this.updatedAttachments = this.updatedAttachments.sort((e) => e.position);
    const idx = this.updatedAttachments.findIndex(
      (e) => e.position == attachment.position
    );
    const switch_with_idx: number =
      idx < this.updatedAttachments.length - 1 ? idx + 1 : 0;
    const tmp: IAttachment = this.updatedAttachments[idx];
    this.updatedAttachments[idx] = this.updatedAttachments[switch_with_idx];
    this.updatedAttachments[switch_with_idx] = tmp;
    this.updatedAttachments = this.updatedAttachments.map((element, i) => {
      element.position = i + 1;
      return element;
    });
  }

  toggleExpand(idx: number) {
    if (this.expandedIndexes.has(idx)) {
      this.expandedIndexes.delete(idx);
    } else {
      this.expandedIndexes.add(idx);
    }
  }

  isExpanded(idx: number): boolean {
    return this.expandedIndexes.has(idx);
  }

  filterAttachment(
    attachments: IAttachment[],
    category: AttachmentCategory = AttachmentCategory.TEXT
  ): IAttachment[] {
    return attachments.filter((e) => e.category === category);
  }

  previousState(): void {
    window.history.back();
  }
}
