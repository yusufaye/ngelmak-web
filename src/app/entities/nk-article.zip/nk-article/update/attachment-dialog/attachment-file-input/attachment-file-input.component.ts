import { CommonModule } from "@angular/common";
import { Component, inject, signal } from "@angular/core";
import { MatDialogModule, MatDialogRef } from "@angular/material/dialog";
import { AttachmentCategory } from "app/entities/nk-enumerations/nk-attachment-type.model";
import { IAttachment } from "../../../../nk-attachment/nk-attachment.model";
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { MatInputModule } from "@angular/material/input";
import { MatFormFieldModule } from "@angular/material/form-field";

@Component({
  standalone: true,
  selector: "app-attachment-file-input",
  templateUrl: "./nk-attachment-file-input.component.html",
  styleUrl: "./nk-attachment-file-input.component.scss",
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,
  ],
})
export class AttachmentFileInputComponent {
  attachment = signal(null);

  readonly dialogRef = inject(MatDialogRef<AttachmentFileInputComponent>);
  attachmentForm = new FormGroup({
    caption: new FormControl("", {
      nonNullable: true,
      validators: [
        Validators.maxLength(50),
        Validators.pattern("^[a-zA-Z0-9!$&+_-]+"),
      ],
    }),
  });

  onFileSelected(event) {
    const file: File = event.target.files[0];
    if (file) {
      const today = new Date();
      this.attachment.set({
        type: file.type,
        size: file.size,
        content: file,
        filename: `DOC_${today.getFullYear()}${
          today.getMonth() + 1
        }${today.getDay()}-${today.getHours()}${today.getMinutes()}${today.getSeconds()}_{file.name}.mp3`,
        caption: this.attachmentForm.getRawValue().caption,
        category: AttachmentCategory.DOCUMENT,
      } as IAttachment);
    }
  }

  save() {
    this.dialogRef.close(this.attachment());
  }
}
