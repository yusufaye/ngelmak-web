import { CommonModule } from "@angular/common";
import { Component, inject, OnInit, signal } from "@angular/core";
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { MatDialogModule, MatDialogRef } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { IAttachment } from "app/entities/nk-attachment/nk-attachment.model";
import { AttachmentCategory } from "app/entities/nk-enumerations/nk-attachment-type.model";
import { VideoPlyrComponent } from "app/shared/video-plyr/video-plyr.component";
import { saveAs } from 'file-saver';

@Component({
  standalone: true,
  selector: "app-attachment-video",
  templateUrl: "./nk-attachment-video.component.html",
  imports: [
    CommonModule,
    ReactiveFormsModule,
    VideoPlyrComponent,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,
  ],
})
export class AttachmentVideoComponent implements OnInit {
  attachment = signal<IAttachment>(null);

  readonly dialogRef = inject(MatDialogRef<AttachmentVideoComponent>);
  attachmentForm = new FormGroup({
    caption: new FormControl("", {
      validators: [Validators.maxLength(100)],
    }),
  });
  videoURL = signal(null);
  posterURL = signal(null);
  frameCaptureAtTimeAsPoster = .5; // Default frame to consider as poster.
  videoFile: File;
  posterFile: Blob;

  ngOnInit(): void {
    if (this.attachment()) {
      this.attachmentForm.patchValue(this.attachment());
      this.videoURL.set(this.attachment().url);
    }
  }

  /**
   * Video handler that loads video and capture poster.
   * @param event
   */
  handleVideo(event) {
    this.videoFile = event.target.files[0];
    if (this.videoFile) {
      this.videoURL.set(URL.createObjectURL(this.videoFile));
      const video = document.createElement("video");
      video.src = this.videoURL();
      video.load();
      video.muted = true
      video.play()
      // 2. Capture the current frame into image.
      video.ontimeupdate = () => {
        if (video.currentTime > 5) {
          const canvas = document.createElement("canvas");
          const canvasContext = canvas.getContext("2d");
          // Set canvas size to match video.
          canvas.width  = video.videoWidth;
          canvas.height = video.videoHeight;
          // Draw the current video image on the canvas.
          canvasContext.drawImage(video, 0, 0, canvas.width, canvas.height);
          // Transform the current canvas as an image url.
          this.posterURL.set(canvas.toDataURL("image/png"));
          canvas.toBlob((blob) => {
            console.log(blob);
            
            saveAs(blob, "pretty_image.png");
            this.posterFile = blob;
          }, "image/png", 1);
          // canvas.toBlob((blob) => (this.posterFile = blob), "image/png", 1);
          video.pause()
        }
      };
      // 1. Set up the default frame to consider as poster.
      video.onloadeddata = () => {

        // move to frame at given time in second.
        // This will trigger the onseeked event to capture the fame as image and save it.
        // video.currentTime = Math.floor(video.duration * this.frameCaptureAtTimeAsPoster);
      };
    }
  }

  /**
   * Data file to use as poster of the video.
   * @param event
   */
  handlePoster(event) {
    this.posterFile = event.target.files[0];
    if (this.posterFile) {
      this.posterURL.set(URL.createObjectURL(this.posterFile));
    }
  }

  done() {
    URL.revokeObjectURL(this.videoURL());
    URL.revokeObjectURL(this.posterURL());
    this.videoURL.set(null);
    this.posterURL.set(null);
    const attachment = {
      type: this.videoFile.type,
      size: this.videoFile.size,
      filename: this.videoFile.name,
      caption: this.attachmentForm.value.caption,
      category: AttachmentCategory.VIDEO,
    } as IAttachment;
    this.dialogRef.close({
      attachment,
      video: this.videoFile,
      poster: this.posterFile,
    });
  }
}
