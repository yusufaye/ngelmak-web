import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { AttachmentCategory } from 'app/entities/nk-enumerations/nk-attachment-type.model';
import { QuillModule } from 'ngx-quill';
import { IAttachment } from '../../../../nk-attachment/nk-attachment.model';

@Component({
  selector: 'app-attachment-text',
  standalone: true,
  templateUrl: './nk-attachment-text.component.html',
  styleUrl: './nk-attachment-text.component.scss',
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatDialogActions,
    MatDialogClose,
    MatDialogTitle,
    MatDialogContent,
    QuillModule,
  ],
})
export class AttachmentTextDialogComponent {
  readonly dialogRef = inject(MatDialogRef<AttachmentTextDialogComponent>);

  textContent: string = '';

  // quillConfiguration = quillConfiguration;
  quillConfiguration = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],
      ['blockquote', 'code-block'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ 'size': [false, 'small', 'large', 'huge'] }],  // custom dropdown
      ['link'],
      ['clean'],
    ],
  };

  save() {
    this.dialogRef.close({
      type: 'text',
      category: AttachmentCategory.TEXT,
      textContent: this.textContent,
    } as IAttachment);
  }
}
