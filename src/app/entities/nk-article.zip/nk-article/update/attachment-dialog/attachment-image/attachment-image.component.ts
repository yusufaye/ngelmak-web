import { CommonModule } from "@angular/common";
import { Component, inject, OnInit, signal } from "@angular/core";
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { MatDialogModule, MatDialogRef } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { IAttachment } from "app/entities/nk-attachment/nk-attachment.model";
import { AttachmentCategory } from "app/entities/nk-enumerations/nk-attachment-type.model";

@Component({
  standalone: true,
  selector: "app-attachment-image",
  templateUrl: "./nk-attachment-image.component.html",
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,
  ],
})
export class AttachmentImageComponent implements OnInit {
  attachment = signal<IAttachment>(null);

  readonly dialogRef = inject(MatDialogRef<AttachmentImageComponent>);
  attachmentForm = new FormGroup({
    caption: new FormControl("", {
      validators: [Validators.maxLength(100)],
    }),
  });
  imageURL = signal(null);
  file: File;

  ngOnInit(): void {
    if (this.attachment()) {
      this.attachmentForm.patchValue(this.attachment());
      this.imageURL.set(this.attachment().url);
    }
  }

  handleImage(event) {
    this.file = event.target.files[0];
    if (this.file) {
      this.imageURL.set(URL.createObjectURL(this.file));
    }
  }

  done() {
    URL.revokeObjectURL(this.imageURL());
    this.imageURL.set(null);
    const attachment = {
      url: this.imageURL(),
      type: this.file.type,
      size: this.file.size,
      filename: this.file.name,
      caption: this.attachmentForm.value.caption,
      category: AttachmentCategory.IMAGE,
      blob: this.file,
    } as IAttachment;
    this.dialogRef.close(attachment);
  }
}
