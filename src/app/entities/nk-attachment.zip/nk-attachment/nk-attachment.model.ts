import { IPost } from 'app/entities/nk-post/nk-post.model';
import { AttachmentCategory } from 'app/entities/enumerations/attachment-type.model';

export interface IAttachment {
  id?: number;
  position?: number;
  type?: string;
  category?: AttachmentCategory;
  textContent?: string;
  caption?: string | null;
  filename?: string;
  duration?: number;
  url?: string | null;
  posterUrl?: string | null;
  size?: number | null;
  post?: IPost | null;
  dirty?: boolean;
  blob?: Blob;
  posterBlob?: Blob;
}
