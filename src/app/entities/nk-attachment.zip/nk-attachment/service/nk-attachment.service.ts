import { HttpClient, HttpResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IAttachment } from '../nk-attachment.model';

export type EntityResponseType = HttpResponse<IAttachment>;
export type EntityArrayResponseType = HttpResponse<IAttachment[]>;

@Injectable({ providedIn: 'root' })
export class AttachmentService {
  protected http = inject(HttpClient);
  protected applicationConfigService = inject(ApplicationConfigService);

  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/nk-attachments');

  create(attachment: IAttachment): Observable<EntityResponseType> {
    return this.http.post<IAttachment>(this.resourceUrl, attachment, { observe: 'response' });
  }

  update(attachment: IAttachment): Observable<EntityResponseType> {
    return this.http.put<IAttachment>(`${this.resourceUrl}/${attachment.id}`, attachment, {
      observe: 'response',
    });
  }

  partialUpdate(attachment: IAttachment): Observable<EntityResponseType> {
    return this.http.patch<IAttachment>(`${this.resourceUrl}/${attachment.id}`, attachment, {
      observe: 'response',
    });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IAttachment>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  findByPost(id: number): Observable<EntityArrayResponseType> {
    return this.http.get<IAttachment[]>(`${this.resourceUrl}/nk-post/${id}`, { observe: 'response' });
  }

  getResource(id: number): Observable<Blob> {
    return this.http.get(`${this.resourceUrl}/${id}/resource`, { responseType: 'blob' });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IAttachment[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

}
